// test

public class MainRabbit {

    public static void main(String[] args){

	RabbitsGrassSimulationModel.main(args);

    } 

}
